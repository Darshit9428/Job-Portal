<!DOCTYPE html>
<html>
<head>
    <link rel="stylesheet" type="text/css" href="stylesheet.css">
    <style>
        .sub {
            background-color: #ff4454;
            height:50px;
            width:100%;
            margin-top: 70px;
            color: white;
            font-size:25px;
        }
        input{
            height:35px;
            width:300px;
        }
        table {
            font:Times New Roman;
            font-size:35px;
            color:#ff4454;
        }
    </style>

</head>
<body >

<div class="header">
    <big><h1> CAMPUS SELECTION SYSTEM</h1></big>

</div>
<div class="navi">
    <a href="home.php">HOME</a>
    <a href="studentReg.php">NEW STUDENT</a>
    <a href="companyReg.php">NEW COMPANY</a>
    <a href="contact.php">CONTACT US</a>
    <a href="aboutus.php">ABOUT US</a>
</div>
<div  class="sub" align="center"><h2><b>ADD EDUCATION DETAILS</b></h2></div><br>
    <div>
        <form method="post" action="studentlogin.php">
            <table align="center">
                <tr>
                    <td>College name:</td>
                    <td><input type="text" name="clgname" placeholder="Enter the college name"; required>
                </tr>
                <tr>
                    <td>Qualification:</td>
                    <td><input type="text" name="qualification" placeholder="Enter the qualification"; required>
                </tr>
                <tr>
                    <td>Branch:</td>
                    <td><input type="text" name="branch" placeholder="Enter the branch"; required>
                </tr>
                <tr>
                    <td>Passing year:</td>
                    <td><input type="number" name="passingyear" placeholder="Enter the passing year"; required>
                </tr>
                <tr>
                    <td>CGPA</td>
                    <td><input type="text" name="cgpa" placeholder="Enter the CGPA"; required>
                </tr>
                <tr>
                    <td>Skills:</td>
                    <td><input type="text" name="skill" placeholder="Enter the skills"; required>
                </tr>
                <tr>
                    <td> </td>
                    <td><input type="button" class="button" id="demo" value="ADD DETAILS" onclick="window.location.href='http://localhost:8080/wt/studentlogin.php'"; required>
                </tr>
            </table>
        </form>
    </div>
</body>
</html>