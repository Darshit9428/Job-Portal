<?php 
session_start();
$conn=mysqli_connect('localhost','root');
if(isset($_POST)){

    $companyname=mysqli_real_escape_string($conn,$_POST['companyname']);
$category=mysqli_real_escape_string($conn,$_POST['category']);
$requiredskill=mysqli_real_escape_string($conn,$_POST['requiredskill']);
$qualification=mysqli_real_escape_string($conn,$_POST['qualification']);
$salary=mysqli_real_escape_string($conn,$_POST['salary']);
$workinghour=mysqli_real_escape_string($conn,$_POST['workinghour']);
$applydate=mysqli_real_escape_string($conn,$_POST['applydate']);

$sql="UPDATE postjob SET category='$category',requiredskill='$requiredskill',qualification='$qualification',salary='$salary',workinghour='$workinghour' WHERE companyname='$_POST[companyname]'";
$stat=mysqli_query($conn,$sql);
$conn->close();
if($stat)
    echo "success";
else
    echo "failed";
?>

