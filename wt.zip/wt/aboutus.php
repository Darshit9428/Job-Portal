<DOCTYPE html>
<html>
	<head>
		
	</head>
	<body>
		<h1>ABOUT US<h1>
                <p>shivam singh<br>
                7878917293<br>
                    sshivam478@gmail.com</p>
                <p>Smit tailor<br>
                    9875623148<br>
                    smittailor07@gmail.com</p>
                <p>Tushar sakhiya<br>
                    7420556156<br>
                    tusharsakhiya08@gmail.com</p>
                <a href="home.php">BACK TO HOME</a>
	</body>
</html>