<?php
session_start();
$companyname=$_POST['companyname'];
$category=$_POST['category'];
$requiredskill=$_POST['requiredskill'];
$qualification=$_POST['qualification'];
$salary=$_POST['salary'];
$workinghour=$_POST['workinghour'];
$applydate=$_POST['applydate'];
$con=mysqli_connect('localhost','root');
mysqli_select_db($con,'job');
$q = "INSERT INTO postjob(companyname,category,requiredskill,qualification,salary,workinghour,applydate)
    values('$companyname','$category','$requiredskill','$qualification',$salary,$workinghour,'$applydate')";
$stat=mysqli_query($con,$q);
mysqli_close($con);


?>


<!DOCTYPE html>
<html>
<head>
    <link rel="stylesheet" type="text/css" href="stylesheet.css">
    <style>
        .sub {
            background-color: #ff4454;
            height:50px;
            width:100%;
            margin-top: 70px;
            color: white;
            font-size:25px;
        }
        input{
            height:35px;
            width:300px;
        }
        table {
            font:Times New Roman;
            font-size:35px;
            color:#ff4454;
        }
    </style>
</head>
<body >

<div class="header">
    <big><h1> CAMPUS SELECTION SYSTEM</h1></big>

</div>
<div class="navi">
    <a href="#">VIEW PROFILE</a>
    <a href="postjob.php">POST JOB</a>
    <a href="logout.php">LOGOUT</a>
    <a href="contact.php">CONTACT US</a>
    <a href="aboutus.php">ABOUT US</a>
</div>
<div  class="sub" align="center"><h2><b>ADD NEW JOB</b></h2></div><br>
<div class="profile">
    <form method="POST" action="postjob.php">
        <table align="center">
            <tr>
                <td></td>
                <td style="color: limegreen;">Posted succesfuly</td>
            </tr>
            <tr>
                <td>Company name:</td>
                <td><input type="text" name="companyname" placeholder="Enter the ccompany name"; required>
            </tr>
            <tr>
                <td>Category:</td>
                <td><input type="text" name="category" placeholder="Enter the category"; required>
            </tr>
            <tr>
                <td>Required Skills:</td>
                <td><input type="text" name="requiredskill" placeholder="Enter the required skills"; required>
            </tr>
            <tr>
                <td>Min Qualification:</td>
                <td><input type="text" name="qualification" placeholder="Enter the minimum qulaification"; required>
            </tr>
            <tr>
                <td>Salary:</td>
                <td><input type="text" name="salary" placeholder="Enter the required salary"; required>
            </tr>
            <tr>
                <td>Working Hour:</td>
                <td><input type="number" name="workinghour" placeholder="Enter the Working hour"; required>
            </tr>
            <tr>
                <td>Last Apply date:</td>
                <td><input type="date" name="applydate";  required>
            </tr>
            <tr>
                <td><input type="reset" value="RESET" class="button" ></td>
                <td><input type="submit" value="SUBMIT" class="button" >
            </tr>
        </table>
    </form>
</div>

</body>
</html>



