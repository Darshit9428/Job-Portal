<?php
$con=mysqli_connect('localhost','root');
mysqli_select_db($con,'job');
$q="select * from postjob";
$result=mysqli_query($con,$q);
$num=mysqli_num_rows($result);
mysqli_close($con);
?>


<!DOCTYPE html>
<html>
<head>
    <link rel="stylesheet" type="text/css" href="stylesheet.css">
    <style>
        .sub {
            background-color: #ff4454;
            height:50px;
            width:100%;
            margin-top: 70px;
            color: white;
            font-size:25px;
        }
        .profile {
            text-align: center;
            font-size:35px;
            color: black;

        }
        input
        {
            height:30px;
        }

        th{
            color:#ff4454;
        }
        table,tr,td,th  {
            border: 2px solid black;
            height:50px;
            text-align: center;
            font-size:25px;
        }
    </style>
</head>
<body >

<div class="header">
    <big><h1> CAMPUS SELECTION SYSTEM</h1></big>

</div>
<div class="navi">
    <a href="#">VIEW PROFILE</a>
    <a href="viewjob.php">FIND JOB</a>
    <a href="logout.php">LOGOUT!!</a>
    <a href="contact.php">CONTACT US</a>
    <a href="aboutus.php">ABOUT US</a>
</div>
<p id="demo"> </p>
<div class="profile">
    <div  class="sub" align="center"><h2><b>VIEW JOB</b></h2></div><br>
    <form method="post" action="updation.php">
    <table align="center">
        <tr>
            <th>ID</th>
            <th>Comapny Name</th>
            <th>Category</th>
            <th>Required Skills</th>
            <th>Min Qualification</th>
            <th>Salary</th>
            <th>Working Hour</th>
            <th>Last Apply date</th>
        </tr>
        <?php
        for($i=1;$i<$num;$i++) {
            $row = mysqli_fetch_array($result);

            ?>
            <tr>
                <td><?php echo $row['id']; ?><input type="hidden" name="id<?php echo $i;?>" value="<?php echo $row['id']; ?>"></td>
                <td><input type="text" name="companyname<?php echo $i;?>" value="<?php echo $row['companyname']; ?>"> </td>
                <td><input type="text" name="category<?php echo $i;?>" value="<?php echo $row['category']; ?>"> </td>
                <td><input type="text" name="requiredskill<?php echo $i;?>" value="<?php echo $row['requiredskill']; ?>"> </td>
                <td><input type="text" name="qualification<?php echo $i;?>" value="<?php echo $row['qualification']; ?>"> </td>
                <td><input type="text" name="salary<?php echo $i;?>" value="<?php echo $row['salary']; ?>"> </td>
                <td><input type="text" name="workinghour<?php echo $i;?>" value="<?php echo $row['workinghour']; ?>"> </td>
                <td><input type="text" name="applydate<?php echo $i;?>" value="<?php echo $row['applydate']; ?>"> </td>

            </tr>

            <?php
        }
        ?>


           <input type="submit" class="button" value="UPDATE" >

    </table>
    </form>
</div>
</body>

</html>
