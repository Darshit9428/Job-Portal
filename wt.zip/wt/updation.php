<?php
$size=sizeof($_POST);
$record=$size/8;
for($i=1;$i<=$record;$i++) {
    $index1 = "id".$i;
    $id[$i] = $_POST[$index1];
    $index2 = "category".$i;
    $category[$i] = $_POST[$index2];
    $index3 = "requiredskill".$i;
    $requiredskill[$i] = $_POST[$index3];
    $index4 = "qualification".$i;
    $qualification[$i] = $_POST[$index4];
    $index5 = "salary".$i;
    $salary[$i] = $_POST[$index5];
    $index6 = "workinghour".$i;
    $workinghour[$i] = $_POST[$index6];
    $index7 = "applydate".$i;
    $applydate[$i] = $_POST[$index7];
}
        $con=mysqli_connect('localhost','root');
        mysqli_select_db($con,'job');
        for($i=1;$i<=$record;$i++)
        {

            $q= "UPDATE postjob SET  category='$category[$i]', requiredskill='$requiredskill[$i]', 
                  qualification='$qualification[$i]', salary=$salary[$i], workinghour=$workinghour[$i], 
                  applydate='$applydate[$i]' WHERE id='$id[$i]'";
            $stat=mysqli_query($con,$q);
        }
        mysqli_close($con);


?>

<!DOCTYPE html>
<html>
<head>

</head>
<body>
<?php
    header("Location:updatejob1.php")
?>
</body>
</html>

