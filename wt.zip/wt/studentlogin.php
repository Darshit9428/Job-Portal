<?php
    session_start();
    $username=$_POST['username'];
    $pwd=$_POST['pwd'];
    $con=mysqli_connect('localhost','root');
    mysqli_select_db($con,'job');
    $q="SELECT username, pwd FROM studentreg WHERE username='$username' && pwd='$pwd'";
    $result=mysqli_query($con,$q);
    $num=mysqli_num_rows($result);
    if($num==1)
    {

        $_SESSION['username']=$username;
        $p="select * from studentreg WHERE username='$username'";
        $res=mysqli_query($con,$p);
        $count=mysqli_num_rows($res);
        mysqli_close($con);
?>

<!DOCTYPE html>
<html>
<head>
    <link rel="stylesheet" type="text/css" href="stylesheet.css">
   <style>
        .sub {
            background-color: #ff4454;
            height:50px;
            width:100%;
            margin-top: 70px;
            color: white;
            font-size:25px;
        }
        .profile {
            text-align: center;
            font-size:35px;
            color: black;

        }
       table,tr,td  {

           height:50px;
           text-align: left;
       }

    </style>
</head>
<body >

<div class="header">
    <big><h1> CAMPUS SELECTION SYSTEM</h1></big>

</div>
<div class="navi">
    <a href="#">VIEW PROFILE</a>
    <a href="viewjob.php">FIND JOB</a>
    <a href="logout.php">LOGOUT!!</a>
    <a href="contact.php">CONTACT US</a>
    <a href="aboutus.php">ABOUT US</a>
</div>
<?php
for($i=1;$i<=$count;$i++) {
$row = mysqli_fetch_array($res);
?>
<div  class="sub" align="center"><h2><b>WELCOME <?php echo $row['fullname'] ?></b></h2></div><br>
    <div class="profile">
    <table  align="center" >
        <tr>
            <th></th>
            <th>PROFILE</th>

        </tr>


        <tr>
                    <td>FULL NAME</td>
                    <td>::</td>
                    <td><?php echo $row['fullname'] ?></td>
                    <td> </td>
                    <td><input type="button" class="button" value="ADD EDUCATION DETAILS" onclick="window.location.href='http://localhost:8080/wt/studentedu.php'"</td>
                    <td><input type="button" class="button" value="VIEW JOB" onclick="window.location.href='http://localhost:8080/wt/viewjob.php'"</td>
                </tr>
                <tr>
                    <td>ADDRESS</td>
                    <td>::</td>
                    <td><?php echo $row['address'] ?></td>
                </tr>
                <tr>
                    <td>CITY</td>
                    <td>::</td>
                    <td><?php echo $row['city'] ?></td>
                </tr>
                <tr>
                    <td>PINCODE</td>
                    <td>::</td>
                    <td><?php echo $row['pincode'] ?></td>
                </tr>
                <tr>
                    <td>BIRTH-DATE</td>
                    <td>::</td>
                    <td><?php echo $row['birthdate'] ?></td>
                </tr>
                <tr>
                    <td>GENDER</td>
                    <td>::</td>
                    <td><?php echo $row['gender'] ?></td>
                </tr>
                <tr>
                    <td>MOBILE NO</td>
                    <td>::</td>
                    <td><?php echo $row['mobile'] ?></td>
                </tr>
                <tr>
                    <td>EMAIL-ID</td>
                    <td>::</td>
                    <td><?php echo $row['email'] ?></td>
                </tr>
                <tr>
                    <td>ENROLLMENT NO</td>
                    <td>::</td>
                    <td><?php echo $row['enroll'] ?></td>
                </tr>
                <tr>
                    <td>USEER NAME</td>
                    <td>::</td>
                    <td><?php echo $row['username'] ?></td>
                </tr>
                <tr>
                    <td>PASSWORD</td>
                    <td>::</td>
                    <td><?php echo $row['pwd'] ?></td>
                </tr>
                <?php
            }
            ?>

    </table>
    </div>
</body>
    </html>
<?php
    }

    else
    {
        header('location:http://localhost:8080/wt/home.php');
    }

?>

