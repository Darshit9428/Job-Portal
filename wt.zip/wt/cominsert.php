<?php
$name=$_POST['name'];
$address=$_POST['address'];
$city=$_POST['city'];
$pincode=$_POST['pincode'];
$contactname=$_POST['contactname'];
$mobile=$_POST['mobile'];
$email=$_POST['email'];
$website=$_POST['website'];
$username=$_POST['username'];
$pwd=$_POST['pwd'];

$con=mysqli_connect('localhost','root');
mysqli_select_db($con,'job');
$q = "INSERT INTO companyreg(companyname,address,city,pincode,contactperson,mobile,email,companyweb,username,pwd)
    values('$name','$address','$city',$pincode,'$contactname',$mobile,'$email','$website','$username','$pwd')";
mysqli_query($con,$q);

?>

<!DOCTYPE html>
<html>
<head>
    <title> Company Registration</title>
    <script>
        function passwordchecking()
        {
            var x = document.getElementById("pwd");

            if (x.type === "password")
            {
                x.type = "text";
            }
            else
            {
                x.type = "password";
            }
        }
    </script>
    <style>
        html
        {
            background: url(s2.jpg) repeat;
            background-size:cover;
        }
        input{
            height:35px;
            width:300px;
        }
        table {
            font:Times New Roman;
            font-size:35px;
            color:#ff4454;
        }
        .header{
            color:white;
            padding:40px;
            text-align:center;
            height:100px;

            text-shadow: 0 0 20px  #ff4454;
        }
        .header h1:hover{
            color:  #ff4454;
            cursor: pointer;
        }
        .navi{

            background: black;
            margin-bottom: 10px;

        }
        .navi a{
            padding:20px 104px;
            display:block;
            background-color: black;
            color:white;
            text-align:center;
            float:left;
            text-decoration:none;
            transition: background 1s;
        }
        .navi a:hover{
            background-color: rgba(154, 154, 154, 0.66);
            color:white;


        }
        .sub {
            background-color: #ff4454;
            height:50px;
            width:100%;
            margin-top: 70px;
            color: white;
            font-size:25px;
        }
        .footer{
            border:solid;
            width:100%;
            height:80px;
            float:left;
            background-color:black;
            color:white;
            text-align:center
        }
        .button {
            background-color: #ff4454;
            border: 2px solid #ff4454;
            color: white;
            height:50px;
            padding: 15px ;
            text-align: center;
            text-decoration: none;
            display: inline-block;
            font-size: 16px;
            margin-bottom: 4px;
            cursor: pointer;
            border-radius: 8px;
        }
        .button:hover{
            background-color:transparent;
            color:#ff4454;
        }
    </style>
</head>
<body >

<div class="main">
    <div class="header">
        <big><h1>ONLINE CAMPUS SELECTION SYSTEM</h1></big>

    </div>
    <div class="navi">
        <a href="home.php">HOME</a>
        <a href="studentReg.php">NEW STUDENT</a>
        <a href="companyReg.php">NEW COMPANY</a>
        <a href="contact.php">CONTACT US</a>
        <a href="aboutus.php">ABOUT US</a>
    </div >
    <div  class="sub" align="center"><h2><b>NEW COMPANY REGISTER</b></h2></div>
    <form method="post" action="cominsert.php">
        <table align="center" >
            <tr>
                <td></td>
                <td><?php if(mysqli_query($con, $q)){

                        echo "Records added successfully.";

                    } else{

                        echo "ERROR: Could not able to execute $q. " . mysqli_error($con);

                    }
                    mysqli_close($con);
                    ?>

                </td>
            </tr>
            <tr>
                <td>Company Name:</td>
                <td><input type="text" name="name" placeholder="Enter the company name"; required>
            </tr>
            <tr>
                <td>Address:</td>
                <td><input type="textarea" name="address" placeholder="Enter the address"; required>
            </tr>
            <tr>
                <td>City:</td>
                <td><input type="text" name="city" placeholder="Enter the city"; required>
            </tr>
            <tr>
                <td>Pincode:</td>
                <td><input type="number" name="pincode" placeholder="Enter the pincode"; required>
            </tr>
            <tr>
                <td>Contact Person Name:</td>
                <td><input type="text" name="contactname" placeholder="contact person name"; required>
            </tr>
            <tr>
                <td>Mobile No:</td>
                <td><input type="number" name="mobile" placeholder="Enter the Mobile No"; required>
            </tr>
            <tr>
                <td>Email Id:</td>
                <td><input type="email" name="email" placeholder="Enter the Email"; required>
            </tr>
            <tr>
                <td>Company Website:</td>
                <td><input type="text" name="website" placeholder="Enter the Website" ; required>
            </tr>
            <tr>
                <td>Username:</td>
                <td><input type="text" name="username" placeholder="Enter the Username"; required>
            </tr>
            <tr>
                <td>Password:</td>
                <td><input type="password" id="pwd" name="pwd" placeholder="Enter the password"; required><br>
                    <input type="checkbox" onclick="passwordchecking()">Show Password</td>

            <tr>
                <td ><input type="reset" class="button" value="RESET"; ></td>
                <td><input type="submit" class="button" value="REGISTER" ; > </td>
            </tr>
        </table>

    </form>

    <div class="footer">
        <h2>All The Right Reserved @ONLINE CAMPUS SELECTION SYSTEM 2018</h2>
    </div>
</div>
</body>
</html>





