<?php

$username=$_POST['username'];
$pwd=$_POST['pwd'];
$con=mysqli_connect('localhost','root');
mysqli_select_db($con,'job');
$q="SELECT username,pwd FROM companyreg WHERE username='$username' && pwd='$pwd'";
$result=mysqli_query($con,$q);
$num=mysqli_num_rows($result);

if($num==1)
{

    $_SESSION['username']=$username;
    $p="select * from companyreg WHERE username='$username' ";
    $res=mysqli_query($con,$p);
    $count=mysqli_num_rows($res);
    mysqli_close($con);
    ?>


    <!DOCTYPE html>
    <html>
    <head>
        <link rel="stylesheet" type="text/css" href="stylesheet.css">
        <style>
            .sub {
                background-color: #ff4454;
                height:50px;
                width:100%;
                margin-top: 70px;
                color: white;
                font-size:25px;
            }
            .profile {
                text-align: center;
                font-size:35px;
                color: black;

            }
            table,tr,td  {

                height:50px;
                text-align: left;
                font-size: 35px;
            }

        </style>
    </head>
    <body >

    <div class="header">
        <big><h1> CAMPUS SELECTION SYSTEM</h1></big>

    </div>
    <div class="navi">
        <a href="#">VIEW PROFILE</a>
        <a href="postjob.php">POST JOB</a>
        <a href="logout.php">LOGOUT!!</a>
        <a href="contact.php">CONTACT US</a>
        <a href="aboutus.php">ABOUT US</a>
    </div>
    <?php
    for($i=1;$i<=$count;$i++) {
    $row = mysqli_fetch_array($res);
    ?>
    <div  class="sub" align="center"><h2><b>Welcome <?php echo $row['companyname'] ?></b></h2></div><br>
    <div class="profile">
        <table  align="center" >
            <tr>
                <th></th>
                <th>PROFILE</th>

            </tr>

            <tr>
                <td>COMPANY NAME</td>
                <td>::</td>
                <td><?php echo $row['companyname'] ?></td>
                <td> </td>
                <td><input type="button" class="button" value="ADD NEW JOB" onclick="window.location.href='http://localhost:8080/wt/postjob.php'"</td>
                <td><input type="button" class="button" value="UPDATE JOB" onclick="window.location.href='http://localhost:8080/wt/updatejob1.php'"</td>
            </tr>
            <tr>
                <td>ADDRESS</td>
                <td>::</td>
                <td><?php echo $row['address'] ?></td>
            </tr>
            <tr>
                <td>CITY</td>
                <td>::</td>
                <td><?php echo $row['city'] ?></td>
            </tr>
            <tr>
                <td>PINCODE</td>
                <td>::</td>
                <td><?php echo $row['pincode'] ?></td>
            </tr>
            <tr>
                <td>CONATCT PERSON NAME</td>
                <td>::</td>
                <td><?php echo $row['contactperson'] ?></td>
            </tr>

            <tr>
                <td>MOBILE NO</td>
                <td>::</td>
                <td><?php echo $row['mobile'] ?></td>
            </tr>
            <tr>
                <td>EMAIL-ID</td>
                <td>::</td>
                <td><?php echo $row['email'] ?></td>
            </tr>
            <tr>
                <td>COMPANY WEBSITE</td>
                <td>::</td>
                <td><?php echo $row['companyweb'] ?></td>
            </tr>
            <tr>
                <td>USEER NAME</td>
                <td>::</td>
                <td><?php echo $row['username'] ?></td>
            </tr>
            <tr>
                <td>PASSWORD</td>
                <td>::</td>
                <td><?php echo $row['pwd'] ?></td>
            </tr>
            <?php
            }
            ?>

        </table>
    </div>
    </body>
    </html>

    <?php
}
else
{
    header('location:http://localhost:8080/wt/home.php');
}
?>