<!DOCTYPE html>
<html>
<head>
	<style>

			html
			{
				background: url(s2.jpg) repeat;
				background-size:cover;
			}
			.header{
					color:white;
					padding:40px;
					text-align:center;
					height:100px;
			}
			.header {
						background: url(s1.jpg) repeat;
						border: 2px solid black;
						border-bottom:none;
						}

			.
			.navi{
				
				margin-bottom:70px; 
				
			}
			.navi a{
				padding:20px 117.5px;
				display:block;
				background-color:black;
				
				
				color:#f1f1f1;
				text-align:center;
				float:left;
				text-decoration:none
			}
			.navi a:hover{
				background-color: transparent;
				color:black;
				
				
			}
			.button {
    background-color: #ff4454;
    border: 2px solid #ff4454;
    color: white;
    padding: 15px 32px;
    text-align: center;
    text-decoration: none;
    display: inline-block;
    font-size: 16px;
    margin: 4px 2px;
    cursor: pointer;
	border-radius: 8px;
}
			.button:hover{
				background-color:transparent;
				color:#ff4454;
			}
			.left
			{
				
				float:left;
				height:1000px;
				width:24%;
				
			}
			.lside{
				border:solid;
				width:340px;
				height:350px;
				float:left;
				margin-right:10px;
			}
			.leftunder
			{
				border:solid;
				width:340px;
				float:left;
				height:600px;
			}
			
			.middle{
				border:solid;
				width:755px;
				height:974px;
				float:left;
				margin-right:10px;
				
			}
			.right
			{
				
				height:1000px;
				width:360px;
				float:right;
			}
			.rightunder{
				border:solid;
				width:360px;
				height:600px;
				float:right;
			}
			
			.rside{
				border:solid;
				width:360px; ;
				height:350px;
				float:right;
				
			}
			.footer{
				border:solid;
				width:100%;
				height:80px;
				float:left;
				background-color:black;
				color:white;
			}
			
			.btn {
    background-color: black;
    border: 2px solid #ff4454;
    color: white;
	
    padding: 9px 45px;
    text-align: center;
    text-decoration: none;
    display: inline-block;
    font-size: 16px;
    cursor: pointer;
    width: 180px;
    display: block;
	border-radius: 2px;
}
		.btn:hover{
					background-color:transparent;
					color:#ff4454;
		}

			.lside,.middle,.rside,.rightunder,.leftunder,.footer{ text-align:center;
									margin-bottom:10px;
									padding-bottom:10px;
			}

			
	</style>
</head>
<body >
	
	<div class="header">
		<big><h1>ONLINE CAMPUS SELECTION SYSTEM</h1></big>

	</div>
	<div class="navi">
		<a href="#">HOME</a>
		<a href="#">JOBS</a>
		<a href="#">CONTACT US</a>
		<a href="#">ABOUT US</a>
		<a href="#">SIGN UP</a>
	</div>
	<div class="body">
	<div class="row">
		<div class="left">
		<div class="lside">
			<h2><mark style="background-color:#ff4454">STUDENT LOGIN<mark></h2><br>
			<table>
				<tr>
					<td><big>USERNAME:   </big>
					<input type="text" style="height:25px; width:200px"><br><br></td>
				</tr>
				<tr>
					<td><big>PASSWORD:<big>
					<input type="password" style="height:25px; width:200px"><br><br></td>
				</tr>
				<tr>
					<td>
						<input type="button" class="button" value="LOGIN" ><br><br>
					</td>
				</tr>
				<tr>
					<td>
						<a href="#">FORGET PASSWORD?</a><br><br>
					</td>
				</tr>
				<tr>
					<td>
						<a href="#">NEW STUDENT?</a>
					</td>
				</tr>
			</table>
			
		</div>
		<div class="leftunder">
			<h2><mark style="background-color:#ff4454">JOBS BY  CATEGORY</h2><br>
			<table bgcolor="red" >
				<tr>
					<a href="#" class="btn">IT</a><br><br>
				</tr>
				<tr>
					<a href="#" class="btn">COMPUTER</a><br><br>
				<tr>
					<a href="#" class="btn">MECHNICAL</a><br><br>
				</tr>
				<tr>
					<a href="#" class="btn">ELECTRICAL</a><br><br>
				</tr>
				<tr>
					<a href="#" class="btn">AUTO MOBILE</a><br><br>
				</tr>
				<tr>
					<a href="#" class="btn">ELECTRONIC</a><br><br>
				</tr>
				<tr>
					<a href="#" class="btn">CIVIL</a><br><br>
				</tr>
			</table>
		</div>
		</div>
		<div class="middle">
			<h2><mark style="background-color:#ff4454">:::::::::  SEARCH ZONE   :::::::::</h2>
			<table>
				<tr>
					<td>
						CATEGORY:<select name="dropdown" style="height:25px; width:200px">
									<option value="IT">IT</option>
									<option value="mech">MECH</option>
									<option value="civil">CIVIL</option>
									<option value="elec">ELECTRICAL</option>
								</select>
						SKILL:<select name="dd" style="height:25px; width:200px">
								<option value="c++">C++</option>
								<option value="java">JAVA</option>
							</select><br><br>
						
							
					<td>
				<tr>
				<tr >
					<td>
						QUALIFICATION:<select name="dropdown" style="height:25px; width:200px">
									<option value="btech">B.Tech</option>
									<option value="mba">MBA</option>
									<option value="bca">BCA</option>
									<option value="diploma">Diploma</option>
								</select>
								<input type="radio" name="sub">SEARCH COMPANY
								<input type="radio" name="sub">SEARCH STUDENT<br><br>
					</td>
				</tr>
				<tr>
					<td>
							<input type="button" class="button" value="SEARCH" >
					</td>
				</tr>
				
			</table>
		</div>
		<div class="right">
		<div class="rside">
			<h2><mark style="background-color:#ff4454">COMPANY LOGIN<mark></h2>
			<table>
				<tr>
					<td><big>USERNAME:   </big>
					<input type="text" style="height:25px; width:200px"><br><br></td>
				</tr>
				<tr>
					<td><big>PASSWORD:<big>
					<input type="password" style="height:25px; width:200px"><br><br></td>
				</tr>
				<tr>
					<td>
						<input type="button" class="button" value="LOGIN" ><br><br>
					</td>
				</tr>
				<tr>
					<td>
						<a href="#">FORGET PASSWORD?</a><br><br>
					</td>
				</tr>
				<tr>
					<td>
						<a href="#">NEW COMPANY?</a>
					</td>
				</tr>
			</table>
		</div>
		<div class="rightunder">
			<h2><mark style="background-color:#ff4454">RECENT COMPANY</h2>
		</div>
		</div>
		
	</div>
	<div class="footer">
		<h2>All The Right Reserved @ONLINE CAMPUS SELECTION SYSTEM 2018</h22>
	</div>
	</div>
</body>
</html>