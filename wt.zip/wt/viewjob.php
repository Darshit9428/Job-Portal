<?php
$con=mysqli_connect('localhost','root');
mysqli_select_db($con,'job');
$q="select * from postjob";
$result=mysqli_query($con,$q);
$num=mysqli_num_rows($result);
mysqli_close($con);
?>


<!DOCTYPE html>
<html>
<head>
    <link rel="stylesheet" type="text/css" href="stylesheet.css">
    <style>
        .sub {
            background-color: #ff4454;
            height:50px;
            width:100%;
            margin-top: 70px;
            color: white;
            font-size:25px;
        }
        .profile {
            text-align: center;
            font-size:35px;
            color: black;

        }
        th{
            color:#ff4454;
        }
        table,tr,td,th  {
            border: 2px solid black;
            height:50px;
            text-align: center;
            font-size:25px;
        }
    </style>
</head>
<body >

<div class="header">
    <big><h1> CAMPUS SELECTION SYSTEM</h1></big>

</div>
<div class="navi">
    <a href="#">VIEW PROFILE</a>
    <a href="viewjob.php">FIND JOB</a>
    <a href="logout.php">LOGOUT!!</a>
    <a href="contact.php">CONTACT US</a>
    <a href="aboutus.php">ABOUT US</a>
</div>
<p id="demo"> </p>
<div class="profile">
    <div  class="sub" align="center"><h2><b>VIEW JOB</b></h2></div><br>
    <table align="center">
            <tr>
                <th>SR.NO</th>
                <th>Comapny Name</th>
                <th>Category</th>
                <th>Required Skills</th>
                <th>Min Qualification</th>
                <th>Salary</th>
                <th>Working Hour</th>
                <th>Last Apply date</th>
            </tr>
        <?php
            for($i=0;$i<$num;$i++) {
                $row = mysqli_fetch_array($result);

                ?>
                <tr>
                    <td><?php echo $i ?></td>
                    <td><?php echo $row['companyname']; ?> </td>
                    <td><?php echo $row['category']; ?> </td>
                    <td><?php echo $row['requiredskill']; ?> </td>
                    <td><?php echo $row['qualification']; ?> </td>
                    <td><?php echo $row['salary']; ?> </td>
                    <td><?php echo $row['workinghour']; ?> </td>
                    <td><?php echo $row['applydate']; ?> </td>
                    <td><input type="button" class="button" value="Apply" onclick="valid()"</td>
                </tr>
                <?php
            }
        ?>
    </table>
</div>
</body>
<script>
    function valid() {
        alert("Applied Successful!!!");
    }
</script>
</html>
