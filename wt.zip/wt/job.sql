-- phpMyAdmin SQL Dump
-- version 3.1.3.1
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Jun 11, 2018 at 01:23 AM
-- Server version: 5.1.33
-- PHP Version: 5.2.9-2

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";

--
-- Database: `job`
--

-- --------------------------------------------------------

--
-- Table structure for table `companyreg`
--

CREATE TABLE IF NOT EXISTS `companyreg` (
  `companyname` varchar(50) NOT NULL,
  `address` varchar(200) NOT NULL,
  `city` varchar(50) NOT NULL,
  `pincode` int(6) NOT NULL,
  `contactperson` varchar(50) NOT NULL,
  `mobile` int(10) NOT NULL,
  `email` varchar(50) NOT NULL,
  `companyweb` varchar(50) NOT NULL,
  `username` varchar(50) NOT NULL,
  `pwd` varchar(50) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `companyreg`
--

INSERT INTO `companyreg` (`companyname`, `address`, `city`, `pincode`, `contactperson`, `mobile`, `email`, `companyweb`, `username`, `pwd`) VALUES
('jhj', 'jkhk', 'h', 552, 'hgh', 78, 'sajd@gam.com', 'jg', 'jk', 'jk'),
('Wipro', 'valsad', 'valsad', 394225, 'dilip patel', 2147483647, 'swipro@gmail.com', 'www.wipro.com', 'wipro', '123456'),
('Infosys', 'gujarat nagar', 'bangalore', 258674, 'Rahul singh', 2147483647, 'infosys@gmail.com', 'infosys.com', 'infosys', '123');

-- --------------------------------------------------------

--
-- Table structure for table `contact`
--

CREATE TABLE IF NOT EXISTS `contact` (
  `fullname` varchar(50) NOT NULL,
  `mobile` int(10) NOT NULL,
  `email` varchar(100) NOT NULL,
  `message` varchar(200) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `contact`
--


-- --------------------------------------------------------

--
-- Table structure for table `postjob`
--

CREATE TABLE IF NOT EXISTS `postjob` (
  `companyname` varchar(50) NOT NULL,
  `id` int(50) NOT NULL AUTO_INCREMENT,
  `category` varchar(50) NOT NULL,
  `requiredskill` varchar(100) NOT NULL,
  `qualification` varchar(50) NOT NULL,
  `salary` int(10) NOT NULL,
  `workinghour` varchar(10) NOT NULL,
  `applydate` varchar(50) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=10 ;

--
-- Dumping data for table `postjob`
--

INSERT INTO `postjob` (`companyname`, `id`, `category`, `requiredskill`, `qualification`, `salary`, `workinghour`, `applydate`) VALUES
('Infosys', 1, 'IT', 'php', 'B.E.', 12000, '12', '2018-04-20'),
('WIPRO', 2, 'IT', 'c', 'B.tech', 25000, '8', '2018-04-20'),
('wipro', 3, 'comp', 'php', 'B.E.', 12000, '7', '2018-04-20'),
('wipro', 4, 'chemical', 'php', 'B.E.', 12000, '8', '2018-04-20'),
('TOPS', 5, 'bca', 'php', 'B.E.', 12000, '8', '2018-04-20'),
('Wipro', 6, 'IT', 'android', 'B.E.', 12000, '9', '2018-04-20'),
('Infosys', 7, 'IT', 'php', 'B.E.', 12000, '8', '2018-04-20'),
('WIPRO', 8, 'IT', 'php', 'B.E.', 12000, '8', '2018-04-20'),
('wipro', 9, 'it', 'java', 'B.E.', 25000, '8', '2018-04-25');

-- --------------------------------------------------------

--
-- Table structure for table `studentreg`
--

CREATE TABLE IF NOT EXISTS `studentreg` (
  `fullname` varchar(50) NOT NULL,
  `address` varchar(200) NOT NULL,
  `city` varchar(50) NOT NULL,
  `pincode` int(6) NOT NULL,
  `birthdate` date NOT NULL,
  `gender` varchar(50) NOT NULL,
  `mobile` int(10) NOT NULL,
  `email` varchar(50) NOT NULL,
  `enroll` int(12) NOT NULL,
  `username` varchar(50) NOT NULL,
  `pwd` varchar(50) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `studentreg`
--

INSERT INTO `studentreg` (`fullname`, `address`, `city`, `pincode`, `birthdate`, `gender`, `mobile`, `email`, `enroll`, `username`, `pwd`) VALUES
('dgfh', 'sdfg', 'uhi', -4, '2017-05-07', 'male', 3546789, 'uio@ghj.sckc', 544, 'iuo', 'ihjo'),
('dgfh', 'sdfg', 'uhi', -4, '2017-05-07', 'male', 3546789, 'uio@ghj.sckc', 544, 'iuo', 'ihjo'),
('smit ', 'surat', 'surat', 395001, '2018-06-05', 'male', 2147483647, 'smit@gmail.com', 2147483647, 'smit', '123'),
('Ravi singh', 'kim', 'surat', 394110, '2018-04-11', 'male', 2147483647, 'sravi@gmail.com', 2147483647, 'ravi', '123456'),
('shivam singh', 'kim', 'surat', 394110, '2017-06-07', 'male', 2147483647, 'sshivam@gmai.com', 2147483647, 'shivam', '123');
