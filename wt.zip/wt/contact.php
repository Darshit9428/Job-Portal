<!DOCTYPE html>
<html>
<head>
    
    <style>
        html
        {
            background: url(s2.jpg) repeat;
            background-size:cover;
        }
        .header{
            color:white;
            padding:40px;
            text-align:center;
            height:100px;

            text-shadow: 0 0 20px  #ff4454;
        }
        .header h1:hover{
            color:  #ff4454;
            cursor: pointer;
        }
        .navi{

            background: black;
            margin-bottom: 10px;

        }
        .navi a{
            padding:20px 103px;
            display:block;
            background-color: black;
            color:white;
            text-align:center;
            float:left;
            text-decoration:none;
            transition: background 1s;
        }
        .navi a:hover{
            background-color: rgba(154, 154, 154, 0.66);
            color:white;


        }
        .sub {
            background-color: #ff4454;
            height:50px;
            width:100%;
            margin-top: 70px;
            color: white;
            font-size:40px;
        }

        body {font-family: Arial, Helvetica, sans-serif;}

        input[type=text], select, textarea {
            width: 100%;
            padding: 12px;
            border: 1px solid #ccc;
            border-radius: 4px;
            box-sizing: border-box;
            margin-top: 6px;
            margin-bottom: 16px;
            resize: vertical;
        }

        .container {
            border-radius: 5px;
            background-color: transparent;
            padding: 20px;
        }
        .button {
            background-color: #ff4454;
            border: 2px solid #ff4454;
            color: white;
            height:70px;
            width:100%;
            padding: 15px ;
            text-align: center;
            text-decoration: none;
            display: inline-block;
            font-size: 35px;
            margin-bottom: 4px;
            cursor: pointer;
            border-radius: 8px;
        }
        .button:hover{
            background-color:transparent;
            color:#ff4454;
        }
    </style>
</head>
<body>
<div class="header">
    <big><h1>ONLINE CAMPUS SELECTION SYSTEM</h1></big>

</div>
<div class="navi">
    <a href="home.php">HOME</a>
    <a href="studentReg.php">NEW STUDENT</a>
    <a href="companyReg.php">NEW COMPANY</a>
    <a href="contact.php">CONTACT US</a>
    <a href="aboutus.php">ABOUT US</a>
</div >

<div class="sub" align="center" <h1>CONTACT FORM</h1></div><br>

<div class="container">
    <form action="home.php">
        <label for="fname">First Name</label>
        <input type="text" id="fname" required name="firstname" placeholder="Your name..">

        <label for="lname">Last Name</label>
        <input type="text" id="lname" required name="lastname" placeholder="Your last name..">

        <label for="country">Country</label>
        <select id="country" required name="country">
            <option value="australia">Australia</option>
            <option value="canada">India</option>
            <option value="usa">USA</option>
        </select>

        <label for="subject">Subject</label>
        <textarea id="subject" name="subject" required placeholder="Write something.." style="height:200px"></textarea>

        <input type="submit" class="button"  value="SUBMIT";>
    </form>
</div>

</body>
</html>
