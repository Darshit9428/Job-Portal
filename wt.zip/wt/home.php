<!DOCTYPE html>
<html>
<head>
	<link rel="stylesheet" type="text/css" href="stylesheet.css">
</head>
<body >
	
	<div class="header">
		<Big><big><h1> ONLINE JOB PORTAL</h1></big></Big>

	</div>
	<div class="navi">
		<a href="home.php">HOME</a>
		<a href="studentReg.php">NEW STUDENT</a>
		<a href="companyReg.php">NEW COMPANY</a>
        <a href="contact.php">CONTACT US</a>
		<a href="aboutus.php">ABOUT US</a>
	</div>
	<div class="body">
	<div class="row">
		<div class="left">
		<div class="lside">
            <form method="post" action="studentlogin.php">
            <div class="lhead"><h2>STUDENT LOGIN</h2></div><br>
			<table>
				<tr>
					<td><big>USERNAME:   </big>
					<input type="text" name="username" style="height:25px; width:200px"required><br><br></td>
				</tr>
				<tr>
					<td><big>PASSWORD:<big>
					<input type="password" name="pwd" style="height:25px; width:200px"required><br><br></td>
				</tr>
				<tr>
					<td>
						<input type="submit" class="button" value="LOGIN" ><br><br>
					</td>
				</tr>

				<tr>
					<td>
						<a href="studentReg.php">CREATE AN ACCOUNT</a>
					</td>
				</tr>
			</table>
            </form>
			
		</div>
		<div class="leftunder">
            <div class="lhead"><h2>JOBS BY  CATEGORY</h2></div><br>

			<table bgcolor="red" >
				<tr>
					<a href="#" class="btn">IT</a><br><br>
				</tr>
				<tr>
					<a href="#" class="btn">COMPUTER</a><br><br>
				<tr>
					<a href="#" class="btn">MECHNICAL</a><br><br>
				</tr>
				<tr>
					<a href="#" class="btn">ELECTRICAL</a><br><br>
				</tr>
				<tr>
					<a href="#" class="btn">AUTO MOBILE</a><br><br>
				</tr>
				<tr>
					<a href="#" class="btn">ELECTRONIC</a><br><br>
				</tr>
				<tr>
					<a href="#" class="btn">CIVIL</a><br><br>
				</tr>
			</table>
		</div>
		</div>
		<form class="middle" method="post" action="search.php">
            <div class="mhead"><h2>:::::::::  SEARCH ZONE   :::::::::</h2></div><br>

            <table>
				<tr>
					<td>
						CATEGORY:<select name="category" style="height:25px; width:200px">
									<option value="IT" >IT</option>
									<option value="mech">MECH</option>
									<option value="civil">CIVIL</option>
									<option value="elec">ELECTRICAL</option>
									<option value="elec">COMPUTER</option>
								</select>
						SKILL:<select name="skill" style="height:25px; width:200px">
								<option value="c++">C++</option>
								<option value="java">JAVA</option>
								<option value="java">PHP</option>
								<option value="java">PYTHON</option>
								<option value="java">C</option>
								<option value="java">JAVASCRIPT</option>
								<option value="java">ANDROID</option>
							</select><br><br>
						
							
					<td>
				<tr>
				<tr >
					<td>
						QUALIFICATION:<select name="qualification" style="height:25px; width:200px">
									<option value="btech">B.Tech</option>
									<option value="mba">MBA</option>
									<option value="bca">BCA</option>
									<option value="diploma">Diploma</option>
									<option value="B.E.">B.E.</option>
								</select>
								<input type="radio" name="sub"  >SEARCH COMPANY
								<input type="radio" name="sub">SEARCH STUDENT<br><br>
					</td>
				</tr>
				<tr>
					<td>
							<input type="submit" class="button" value="SEARCH" >
					</td>
				</tr>
				
			</table>

        </form>
		</div>
		<div class="right">
		<div class="rside">
            <form method="post" action="complogin.php">
            <div class="rhead"><h2>COMPANY LOGIN<mark></h2></div><br>
			<table>
				<tr>
					<td><big>USERNAME:   </big>
					<input type="text" name="username" style="height:25px; width:200px"required><br><br></td>
				</tr>
				<tr>
					<td><big>PASSWORD:<big>
					<input type="password" name="pwd" style="height:25px; width:200px"required><br><br></td>
				</tr>
				<tr>
					<td>
						<input type="submit" class="button" value="LOGIN" ><br><br>
					</td>
				</tr>

				<tr>
					<td>
						<a href="companyReg.php">CREATE AN ACCOUNT</a>
					</td>
				</tr>
			</table>
            </form>
		</div>
		<div class="rightunder">
            <div class="rhead"><h2>RECENT COMPANY</h2></div>
		</div>
		</div>
		
	</div>
	<div class="footer">
		<h2>All The Right Reserved @ONLINE CAMPUS SELECTION SYSTEM 2018</h2>
	</div>
	</div>
</body>
</html>