<?php
	$source=("http://localhost/darshit/data.txt");
	$dest='new.txt';
	$data=file_get_contents($source);
	
	$handle=fopen($dest,"w");
	fwrite($dest,$data);
	fclose($handle);
?>