<!DOCTYPE html>
<html>
<head>
	<title> Student Registration</title>
	<script>
						function passwordchecking() 
						{
    								var x = document.getElementById("pwd");
    								
								if (x.type === "password")
								{
        								x.type = "text";
    								} 
								else 
								{
        								x.type = "password";
 	   							}
						}
					</script>
	<style>
        html
        {
            background: url(s2.jpg) repeat;
            background-size:cover;
        }
        input{
            height:35px;
            width:300px;
        }
        table {
            font:Times New Roman;
            font-size:35px;
            color:#ff4454;
        }
        .header{
            color:white;
            padding:40px;
            text-align:center;
            height:100px;

            text-shadow: 0 0 20px  #ff4454;
        }
        .header h1:hover{
            color:  #ff4454;
            cursor: pointer;
        }
        .gen
        {
            width:40px;
        }
        .navi{

            background: black;
            margin-bottom: 10px;

        }
        .navi a{
            padding:20px 104px;
            display:block;
            background-color: black;
            color:white;
            text-align:center;
            float:left;
            text-decoration:none;
            transition: background 1s;
        }
        .navi a:hover{
            background-color: rgba(154, 154, 154, 0.66);
            color:white;


        }
        .sub {
            background-color: #ff4454;
            height:50px;
            width:100%;
            color: white;
            margin-top: 70px;
            font-size:25px;
        }
        .footer{
            border:solid;
            width:100%;
            height:80px;
            float:left;
            background-color:black;
            color:white;
            text-align:center
        }
        .button {
            background-color: #ff4454;
            border: 2px solid #ff4454;
            color: white;
            height:50px;
            padding: 15px ;
            text-align: center;
            text-decoration: none;
            display: inline-block;
            font-size: 16px;
            margin-bottom: 4px;
            cursor: pointer;
            border-radius: 8px;
        }
        .button:hover{
            background-color:transparent;
            color:#ff4454;
        }
    </style>
    </style>

</head>
<body >
	
	<div class="main">
	<div class="header">
		<big><h1>ONLINE CAMPUS SELECTION SYSTEM</h1></big>

	</div>
	<div class="navi">
		<a href="home.php">HOME</a>
		<a href="studentreg.php">NEW STUDENT</a>
		<a href="companyreg.php">NEW COMPANY</a>
		<a href="contact.php">CONATCT US</a>
		<a href="aboutus.php">ABOUT US</a>
	</div align="center">
		<div  class="sub" align="center"><h2><b>NEW STUDENT REGISTER</b></h2></div>
		<form method="POST" action="stuinsert.php" >
			<table align="center" >
				<tr>
					<td>Full Name:</td>
					<td><input type="text" name="name" placeholder="Enter the name"; required>
				</tr>
				<tr>
					<td>Address:</td>
					<td><input type="textarea" name="address" placeholder="Enter the address"; required>
				</tr>
				<tr>
					<td>City:</td>
					<td><input type="text" name="city" placeholder="Enter the city"; required>
				</tr>
				<tr>
					<td>Pincode:</td>
					<td><input type="number" name="pincode" placeholder="Enter the pincode"; required>
				</tr>
				<tr>
					<td>Birth-date:</td>
					<td><input type="date" name="birth" placeholder="Enter the Birthdate"; required><td>
				</tr>
				<tr>
					<td>Gender:</td>
					<td><input class="gen" type="radio" name="gender" value="male";checked>Male
					<input type="radio" class="gen" name="gender" value="female";>Female</td>
				</tr>
				<tr>
					<td>Mobile No:</td>
					<td><input type="number" name="mobile" placeholder="Enter the Mobile No"; required>
				</tr>
				<tr>
					<td>Email Id:</td>
					<td><input type="email" name="email" placeholder="Enter the Email"; required>
				</tr>
				<tr>
					<td>Enroll No:</td>
					<td><input type="number" name="enroll" placeholder="Enter the Enrollment" ; required>
				</tr>
				<tr>
					<td>Username:</td>
					<td><input type="text" name="username" placeholder="Enter the Username"; required>
				</tr>
				<tr>
					<td>Password:</td>
					<td><input type="password" id="pwd" name="pwd" placeholder="Enter the password"; required><br>
					<input type="checkbox" class="gen"  onclick="passwordchecking()">Show Password</td>

				<tr>
					<td> </td>
					<td ><input type="submit" class="button" value="REGISTER"; onclick="studentreg.php" ></td>
				</tr>
			</table>
		</form>
		<div class="footer">
		<h2>All The Right Reserved @ONLINE CAMPUS SELECTION SYSTEM 2018</h2>
	</div>
	</div>
</body>
</html>
